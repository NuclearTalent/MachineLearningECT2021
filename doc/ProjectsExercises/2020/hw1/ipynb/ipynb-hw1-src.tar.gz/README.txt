This IPython notebook hw1.ipynb does not require any additional
programs.
